// Programa para calcular RFC 
// iniciamos con librerias estandar y una especial que aopoya con los caracteres de  forma individual
#include <iostream>
#include <string>
#include <ctype.h>
using namespace std;

// iniciamos con la configuracion de vocales primordiales para no gnerar palabras malas 

char ObtenerPrimeraVocalInterna(const string& str) {
    for (size_t i = 1; i < str.length(); ++i) {
        char c = str[i];
        if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
            return c;
        }
    }
    return 'X';
}

// configuracion de los caracteres a tomar en cuenta para generar el RFC
string CalcularRFC(const string& Nombre, const string& ApellidoPaterno, const string& ApellidoMaterno, const string& FechaNacimiento) {
    string rfc;
    char LetraInicial = ApellidoPaterno[0];
    char PrimeraVocalInterna = ObtenerPrimeraVocalInterna(ApellidoPaterno);
    // se configuro eel apellido materno por si el usuario no cuenta con el mismo 
    char InicialApellidoMaterno = (!ApellidoMaterno.empty()) ? ApellidoMaterno[0] : 'X';
    char InicialNombre = Nombre[0];
    // configuarcion de los datos en pocicion exacta a tomar de la fecha de nacimiento 
    string anio = FechaNacimiento.substr(2, 2);
    string mes = FechaNacimiento.substr(5, 2);
    string dia = FechaNacimiento.substr(8, 2);

    rfc = LetraInicial;
    rfc += PrimeraVocalInterna;
    rfc += InicialApellidoMaterno;
    rfc += InicialNombre;
    rfc += anio;
    rfc += mes;
    rfc += dia;
    return rfc;

}

// configuiracion que ayuda a verificar las palabras inconvenientes con una base de datos 
bool ValidarRFC(string rfc) {
    if (rfc.substr(0, 4) == "BUEI" || rfc.substr(0, 4) == "CACA" || rfc.substr(0, 4) == "CAGA" || rfc.substr(0, 4) == "CAKA" || rfc.substr(0, 4) == "COGE" || rfc.substr(0, 4) == "COJE" || rfc.substr(0, 4) == "COJO" || rfc.substr(0, 4) == "FETO" || rfc.substr(0, 4) == "JOTO" || rfc.substr(0, 4) == "KACO" || rfc.substr(0, 4) == "KAGO" || rfc.substr(0, 4) == "KOJO" || rfc.substr(0, 4) == "KULO" || rfc.substr(0, 4) == "MAMO" || rfc.substr(0, 4) == "MEAS" || rfc.substr(0, 4) == "MION" || rfc.substr(0, 4) == "MULA" || rfc.substr(0, 4) == "PEDO" || rfc.substr(0, 4) == "PUTA" || rfc.substr(0, 4) == "QULO" || rfc.substr(0, 4) == "RUIN") {
        return false;
    }
    return true;
}

// inicio con la interfaz del usuario para el ingreso de su informacion 
int main() {
    string Nombre, ApellidoPaterno, ApellidoMaterno, FechaNacimiento;

    cout << "Programa para Generar RFC, Favor de ingresar datos solo en mayusculas, gracias." << endl << endl;

    cout << "Ingrese su nombre: ";
    getline(cin, Nombre);

    cout << "Ingrese su apellido Paterno: ";
    getline(cin, ApellidoPaterno);

    cout << "Ingrese su apellido Materno (En caso de que no tenga apellido Materno presione enter): ";
    getline(cin, ApellidoMaterno);

    cout << "Ingrese su Fecha de Nacimiento en el formato (YYYY-MM-DD): ";
    getline(cin, FechaNacimiento);

    // se formula el rfc con los para metros que configuramos 
    string rfc = CalcularRFC(Nombre, ApellidoPaterno, ApellidoMaterno, FechaNacimiento);
    if (!ValidarRFC(rfc)) {
        rfc[3] = 'X';
    }
    // se entrtega al usuario su rfc para que pueda confirmarlo 
    cout << "El RFC para: " << Nombre << " " << ApellidoPaterno << " " << ApellidoMaterno << " es: " << rfc << endl;

    return 0;
}